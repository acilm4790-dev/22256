
import { GoogleGenAI, Modality, Type } from "@google/genai";

export const generateProjectData = async (name: string, type: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `قم ببرمجة مشروع علمي تفاعلي بعنوان "${name}" في مختبر ال${type}.
  أريدك أن تعيد لي ملف JSON يحتوي على قسمين:
  1. "guide": شرح باللغة العربية للخطوات والتفسير العلمي.
  2. "config": كود برمجي (إعدادات) للمحاكي يتبع هذا النمط حسب التخصص:
     - إذا كان فيزياء: { "gravity": number, "length": number, "angle": number }
     - إذا كان كيمياء: { "initialPH": number, "beakerColor": string, "reactionSpeed": number }
     - إذا كان رياضيات: { "sides": number, "scale": number, "autoRotate": boolean }
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            guide: { type: Type.STRING },
            config: { type: Type.OBJECT }
          },
          required: ["guide", "config"]
        }
      }
    });
    return JSON.parse(response.text);
  } catch (error) {
    console.error("Gemini Project Generation Error:", error);
    return null;
  }
};

export const generateExplanation = async (prompt: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        systemInstruction: "أنت عالم خبير ومساعد مختبر تفاعلي. اشرح المفاهيم العلمية بطريقة بسيطة ومشوقة باللغة العربية.",
      }
    });
    return response.text;
  } catch (error) {
    return "عذراً، واجهت مشكلة في الاتصال.";
  }
};

export const speakExplanation = async (text: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
        },
      },
    });
    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  } catch (error) {
    return null;
  }
};

export const playPCM = async (base64Data: string) => {
  const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
  const binaryString = atob(base64Data);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
  const dataInt16 = new Int16Array(bytes.buffer);
  const buffer = audioContext.createBuffer(1, dataInt16.length, 24000);
  const channelData = buffer.getChannelData(0);
  for (let i = 0; i < dataInt16.length; i++) channelData[i] = dataInt16[i] / 32768.0;
  const source = audioContext.createBufferSource();
  source.buffer = buffer;
  source.connect(audioContext.destination);
  source.start();
};
