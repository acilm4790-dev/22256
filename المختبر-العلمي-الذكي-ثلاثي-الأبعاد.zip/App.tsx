
import React, { useState } from 'react';
import * as Router from 'react-router-dom';
const { HashRouter, Routes, Route, Link, useLocation } = Router as any;

import { 
  Beaker, 
  Atom, 
  Calculator, 
  Home, 
  Settings, 
  Info, 
  PlusCircle,
  FolderOpen
} from 'lucide-react';
import HomeView from './components/HomeView';
import ChemistryLab from './labs/ChemistryLab';
import PhysicsLab from './labs/PhysicsLab';
import MathLab from './labs/MathLab';
import UserProjectLab from './labs/UserProjectLab';
import Assistant from './components/Assistant';

const Navigation = () => {
  const location = useLocation();
  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="fixed bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-4 px-6 py-4 glass-panel rounded-full z-50 transition-all duration-300">
      <Link to="/" className={`p-3 rounded-full transition-all ${isActive('/') ? 'bg-blue-600 text-white' : 'hover:bg-white/10'}`}>
        <Home size={24} />
      </Link>
      <Link to="/chemistry" className={`p-3 rounded-full transition-all ${isActive('/chemistry') ? 'bg-pink-600 text-white' : 'hover:bg-white/10'}`}>
        <Beaker size={24} />
      </Link>
      <Link to="/physics" className={`p-3 rounded-full transition-all ${isActive('/physics') ? 'bg-emerald-600 text-white' : 'hover:bg-white/10'}`}>
        <Atom size={24} />
      </Link>
      <Link to="/math" className={`p-3 rounded-full transition-all ${isActive('/math') ? 'bg-amber-600 text-white' : 'hover:bg-white/10'}`}>
        <Calculator size={24} />
      </Link>
    </nav>
  );
};

const Header = () => (
  <header className="fixed top-0 left-0 right-0 p-6 flex justify-between items-center z-40">
    <div className="flex items-center gap-3">
      <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center shadow-lg transform rotate-12">
        <Atom className="text-white" size={24} />
      </div>
      <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-400">
        المختبر الذكي
      </h1>
    </div>
    <div className="flex gap-4">
      <button className="p-2 glass-panel rounded-lg hover:bg-white/10 transition-colors">
        <Settings size={20} />
      </button>
    </div>
  </header>
);

const App: React.FC = () => {
  return (
    <Router.HashRouter>
      <div className="min-h-screen relative overflow-hidden text-right" dir="rtl">
        <div className="absolute -top-20 -right-20 w-96 h-96 bg-blue-600/10 blur-[120px] rounded-full" />
        <div className="absolute top-1/2 -left-20 w-80 h-80 bg-purple-600/10 blur-[120px] rounded-full" />
        
        <Header />
        
        <main className="container mx-auto px-4 pt-24 pb-32">
          <Routes>
            <Route path="/" element={<HomeView />} />
            <Route path="/chemistry" element={<ChemistryLab />} />
            <Route path="/physics" element={<PhysicsLab />} />
            <Route path="/math" element={<MathLab />} />
            <Route path="/project/:id" element={<UserProjectLab />} />
          </Routes>
        </main>

        <Assistant />
        <Navigation />
      </div>
    </Router.HashRouter>
  );
};

export default App;
