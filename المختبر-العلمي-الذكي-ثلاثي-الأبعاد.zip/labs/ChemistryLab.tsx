
import React, { useState, useEffect } from 'react';
import { Droplet, RefreshCcw, Info } from 'lucide-react';

const ChemistryLab: React.FC = () => {
  const [beakerColor, setBeakerColor] = useState('rgba(100, 150, 255, 0.4)');
  const [isReacting, setIsReacting] = useState(false);
  const [pH, setPH] = useState(7);
  const [chemicalName, setChemicalName] = useState('ماء نقي (H2O)');

  const addChemical = (type: 'acid' | 'base') => {
    setIsReacting(true);
    setTimeout(() => {
      if (type === 'acid') {
        setBeakerColor('rgba(255, 100, 100, 0.6)');
        setPH(Math.max(1, pH - 2.5));
        setChemicalName('حمض الهيدروكلوريك (HCl)');
      } else {
        setBeakerColor('rgba(100, 100, 255, 0.6)');
        setPH(Math.min(14, pH + 2.5));
        setChemicalName('هيدروكسيد الصوديوم (NaOH)');
      }
      setIsReacting(false);
    }, 800);
  };

  const reset = () => {
    setBeakerColor('rgba(100, 150, 255, 0.4)');
    setPH(7);
    setChemicalName('ماء نقي (H2O)');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
      <div className="glass-panel p-8 rounded-3xl relative min-h-[500px] flex items-center justify-center overflow-hidden">
        {/* 3D Beaker Simulation */}
        <div className="relative w-48 h-64 border-x-4 border-b-4 border-white/20 rounded-b-3xl transform transition-transform duration-700">
          <div 
            className="absolute bottom-0 left-0 right-0 transition-all duration-1000 ease-in-out rounded-b-2xl overflow-hidden"
            style={{ 
              height: '80%', 
              backgroundColor: beakerColor,
              boxShadow: `0 0 30px ${beakerColor}`
            }}
          >
            {/* Bubbles if reacting */}
            {isReacting && (
              <div className="absolute inset-0 flex justify-around items-end pb-4">
                {[1, 2, 3, 4, 5].map(i => (
                  <div 
                    key={i} 
                    className="w-3 h-3 bg-white/30 rounded-full animate-bounce" 
                    style={{ animationDelay: `${i * 0.2}s` }}
                  />
                ))}
              </div>
            )}
            {/* Liquid wave effect */}
            <div className="absolute top-0 left-0 right-0 h-4 bg-white/20 blur-sm transform -translate-y-1/2" />
          </div>
        </div>

        <div className="absolute top-6 left-6 flex items-center gap-2 px-4 py-2 bg-white/5 rounded-full border border-white/10">
          <Info size={16} className="text-blue-400" />
          <span className="text-sm font-mono">{chemicalName}</span>
        </div>
      </div>

      <div className="space-y-6">
        <h2 className="text-3xl font-bold mb-4">تفاعلات الأحماض والقواعد</h2>
        <p className="text-white/60 text-lg mb-8">
          قم بإضافة مواد كيميائية مختلفة إلى البيكر لمشاهدة تفاعل الأس الهيدروجيني (pH) وتغير اللون الفوري.
        </p>

        <div className="grid grid-cols-2 gap-4">
          <button 
            onClick={() => addChemical('acid')}
            className="flex items-center justify-center gap-3 p-6 glass-panel rounded-2xl border-l-4 border-red-500 hover:bg-red-500/10 transition-all"
          >
            <Droplet className="text-red-500" />
            <span className="font-bold">إضافة حمض</span>
          </button>
          <button 
            onClick={() => addChemical('base')}
            className="flex items-center justify-center gap-3 p-6 glass-panel rounded-2xl border-l-4 border-blue-500 hover:bg-blue-500/10 transition-all"
          >
            <Droplet className="text-blue-500" />
            <span className="font-bold">إضافة قاعدة</span>
          </button>
        </div>

        <div className="p-8 glass-panel rounded-2xl">
          <div className="flex justify-between items-center mb-4">
            <span className="text-lg font-semibold">مقياس pH الرقمي</span>
            <span className={`text-4xl font-bold ${pH < 7 ? 'text-red-400' : pH > 7 ? 'text-blue-400' : 'text-emerald-400'}`}>
              {pH.toFixed(1)}
            </span>
          </div>
          <div className="w-full h-4 bg-white/10 rounded-full overflow-hidden flex">
            {Array.from({length: 14}).map((_, i) => (
              <div 
                key={i} 
                className={`flex-1 h-full transition-opacity duration-500 ${Math.round(pH) === i + 1 ? 'opacity-100' : 'opacity-20'}`}
                style={{ backgroundColor: `hsl(${i * 20}, 70%, 50%)` }}
              />
            ))}
          </div>
        </div>

        <button 
          onClick={reset}
          className="w-full flex items-center justify-center gap-2 p-4 bg-white/5 rounded-2xl hover:bg-white/10 transition-all border border-white/10"
        >
          <RefreshCcw size={20} />
          إعادة تعيين التجربة
        </button>
      </div>
    </div>
  );
};

export default ChemistryLab;
