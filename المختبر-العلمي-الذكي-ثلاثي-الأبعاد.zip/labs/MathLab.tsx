
import React, { useState } from 'react';
import { Box, Layers, MousePointer2, Calculator, RefreshCcw } from 'lucide-react';

const MathLab: React.FC = () => {
  const [sides, setSides] = useState(3);
  const [scale, setScale] = useState(1);
  const [rotation, setRotation] = useState(0);

  // Math calculations
  const area = (0.5 * sides * Math.pow(scale * 10, 2) / Math.tan(Math.PI / sides)).toFixed(2);
  const perimeter = (sides * scale * 10).toFixed(2);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
      <div className="glass-panel p-8 rounded-3xl relative min-h-[500px] flex items-center justify-center perspective-[1000px]">
        {/* CSS 3D Shape Simulation */}
        <div 
          className="relative w-48 h-48 transition-all duration-500"
          style={{ 
            transform: `rotateY(${rotation}deg) rotateX(20deg) scale(${scale})`,
            transformStyle: 'preserve-3d'
          }}
        >
          {/* Main Polygon Face */}
          <div 
            className="absolute inset-0 bg-amber-500/40 border-4 border-amber-500 flex items-center justify-center"
            style={{ 
              clipPath: `polygon(${Array.from({length: sides}).map((_, i) => {
                const angle = (i / sides) * 2 * Math.PI;
                return `${50 + 50 * Math.cos(angle)}% ${50 + 50 * Math.sin(angle)}%`;
              }).join(',')})`,
              transform: 'translateZ(20px)'
            }}
          >
            <Box size={40} className="text-white opacity-40" />
          </div>

          {/* Shadow/Base Face */}
          <div 
            className="absolute inset-0 bg-black/40 blur-md"
            style={{ 
              clipPath: `polygon(${Array.from({length: sides}).map((_, i) => {
                const angle = (i / sides) * 2 * Math.PI;
                return `${50 + 50 * Math.cos(angle)}% ${50 + 50 * Math.sin(angle)}%`;
              }).join(',')})`,
              transform: 'translateZ(-20px) scale(1.1)'
            }}
          />
        </div>

        <div className="absolute top-6 left-6 right-6 flex justify-between">
           <div className="glass-panel px-4 py-2 rounded-xl text-sm font-bold border-l-4 border-amber-500">
              المضلع: {sides} أضلاع
           </div>
           <button 
            onClick={() => setRotation(r => r + 45)}
            className="p-2 glass-panel rounded-lg hover:bg-white/10"
           >
              <RefreshCcw size={16} />
           </button>
        </div>
      </div>

      <div className="space-y-6">
        <h2 className="text-3xl font-bold mb-4">هندسة الأشكال المنتظمة</h2>
        <p className="text-white/60 text-lg mb-8">
          استكشف الخصائص الهندسية للمضلعات المنتظمة وحسابات المساحة والمحيط بتمثيل بصري ثلاثي الأبعاد.
        </p>

        <div className="grid grid-cols-2 gap-4">
          <div className="p-6 glass-panel rounded-2xl border-b-4 border-amber-500/30">
            <span className="block text-white/50 text-sm mb-1">المساحة التقريبية</span>
            <span className="text-2xl font-bold text-amber-400">{area} وحدة²</span>
          </div>
          <div className="p-6 glass-panel rounded-2xl border-b-4 border-amber-500/30">
            <span className="block text-white/50 text-sm mb-1">المحيط التقريبي</span>
            <span className="text-2xl font-bold text-amber-400">{perimeter} وحدة</span>
          </div>
        </div>

        <div className="space-y-8 mt-6">
          <div className="space-y-4">
            <div className="flex justify-between">
              <label className="font-semibold">عدد الأضلاع</label>
              <div className="flex gap-2">
                {[3, 4, 5, 6, 8].map(s => (
                  <button 
                    key={s}
                    onClick={() => setSides(s)}
                    className={`w-8 h-8 rounded flex items-center justify-center transition-all ${sides === s ? 'bg-amber-600 text-white' : 'glass-panel hover:bg-white/10'}`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex justify-between">
              <label className="font-semibold">مقياس الحجم</label>
              <span className="text-amber-400 font-mono">x{scale.toFixed(1)}</span>
            </div>
            <input 
              type="range" min="0.5" max="2" step="0.1" value={scale} 
              onChange={(e) => setScale(Number(e.target.value))}
              className="w-full accent-amber-500 h-2 bg-white/10 rounded-lg appearance-none cursor-pointer"
            />
          </div>
        </div>

        <button className="w-full flex items-center justify-center gap-3 p-6 bg-amber-600 rounded-2xl font-bold text-white shadow-lg hover:bg-amber-500 transition-all">
          <Calculator size={24} />
          عرض المعادلات الرياضية كاملة
        </button>
      </div>
    </div>
  );
};

export default MathLab;
