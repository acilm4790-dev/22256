
import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RefreshCcw, Activity } from 'lucide-react';

const PhysicsLab: React.FC = () => {
  const [angle, setAngle] = useState(45);
  const [length, setLength] = useState(200);
  const [isPlaying, setIsPlaying] = useState(false);
  const [time, setTime] = useState(0);

  useEffect(() => {
    let animationFrameId: number;
    if (isPlaying) {
      const update = () => {
        setTime(prev => prev + 0.05);
        animationFrameId = requestAnimationFrame(update);
      };
      animationFrameId = requestAnimationFrame(update);
    }
    return () => cancelAnimationFrame(animationFrameId);
  }, [isPlaying]);

  const currentAngle = isPlaying 
    ? angle * Math.cos(Math.sqrt(9.81 / (length / 100)) * time)
    : angle;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
      <div className="glass-panel p-8 rounded-3xl relative min-h-[500px] flex justify-center overflow-hidden">
        {/* Pendulum Simulation */}
        <div className="absolute top-0 left-1/2 w-1 h-8 bg-white/40 transform -translate-x-1/2" />
        
        <div 
          className="absolute top-0 left-1/2 origin-top transition-transform duration-75"
          style={{ 
            height: `${length}px`,
            transform: `translateX(-50%) rotate(${currentAngle}deg)`
          }}
        >
          <div className="w-1 h-full bg-gradient-to-b from-white/60 to-transparent" />
          <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-12 h-12 bg-emerald-500 rounded-full shadow-[0_0_40px_rgba(16,185,129,0.5)] border-4 border-white/20" />
        </div>

        <div className="absolute bottom-8 left-8 right-8 flex justify-between">
           <div className="glass-panel px-4 py-2 rounded-xl text-sm font-mono">
              الزاوية: {currentAngle.toFixed(1)}°
           </div>
           <div className="glass-panel px-4 py-2 rounded-xl text-sm font-mono">
              الزمن: {time.toFixed(2)}s
           </div>
        </div>
      </div>

      <div className="space-y-6">
        <h2 className="text-3xl font-bold mb-4">فيزياء النواس (البندول)</h2>
        <p className="text-white/60 text-lg mb-8">
          تحكم في طول الخيط وزاوية البداية لدراسة تأثير الجاذبية على الحركة التوافقية البسيطة.
        </p>

        <div className="space-y-6 p-8 glass-panel rounded-2xl">
          <div className="space-y-4">
            <div className="flex justify-between">
              <label className="font-semibold">طول الخيط (سم)</label>
              <span className="text-emerald-400 font-mono">{length}</span>
            </div>
            <input 
              type="range" min="100" max="350" value={length} 
              onChange={(e) => setLength(Number(e.target.value))}
              className="w-full accent-emerald-500 h-2 bg-white/10 rounded-lg appearance-none cursor-pointer"
            />
          </div>

          <div className="space-y-4">
            <div className="flex justify-between">
              <label className="font-semibold">زاوية الإطلاق</label>
              <span className="text-emerald-400 font-mono">{angle}°</span>
            </div>
            <input 
              type="range" min="10" max="80" value={angle} 
              onChange={(e) => setAngle(Number(e.target.value))}
              className="w-full accent-emerald-500 h-2 bg-white/10 rounded-lg appearance-none cursor-pointer"
            />
          </div>
        </div>

        <div className="flex gap-4">
          <button 
            onClick={() => setIsPlaying(!isPlaying)}
            className={`flex-1 flex items-center justify-center gap-3 p-6 rounded-2xl transition-all font-bold ${isPlaying ? 'bg-red-500/20 text-red-500 border border-red-500/50' : 'bg-emerald-600 text-white shadow-lg'}`}
          >
            {isPlaying ? <Pause size={24} /> : <Play size={24} />}
            {isPlaying ? 'إيقاف التجربة' : 'بدء التجربة'}
          </button>
          <button 
            onClick={() => { setTime(0); setIsPlaying(false); }}
            className="p-6 glass-panel rounded-2xl hover:bg-white/10 transition-all"
          >
            <RefreshCcw size={24} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default PhysicsLab;
