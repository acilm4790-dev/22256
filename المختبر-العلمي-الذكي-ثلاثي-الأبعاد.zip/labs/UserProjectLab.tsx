
import React, { useState, useEffect } from 'react';
import * as Router from 'react-router-dom';
const { useParams, useNavigate } = Router as any;
import { ArrowRight, BookOpen, Sparkles, Volume2, Code, Save, Play } from 'lucide-react';
import ChemistryLab from './ChemistryLab';
import PhysicsLab from './PhysicsLab';
import MathLab from './MathLab';
import { speakExplanation, playPCM } from '../services/gemini';

interface Project {
  id: string;
  name: string;
  type: 'physics' | 'chemistry' | 'math';
  description: string;
  guide?: string;
  config: any;
}

const UserProjectLab: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [project, setProject] = useState<Project | null>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [showCode, setShowCode] = useState(false);
  const [editableCode, setEditableCode] = useState('');

  useEffect(() => {
    const saved = localStorage.getItem('science_projects');
    if (saved) {
      const projects = JSON.parse(saved) as Project[];
      const found = projects.find(p => p.id === id);
      if (found) {
        setProject(found);
        setEditableCode(JSON.stringify(found.config, null, 2));
      } else navigate('/');
    }
  }, [id, navigate]);

  const handleSaveCode = () => {
    try {
      const newConfig = JSON.parse(editableCode);
      const updatedProject = { ...project!, config: newConfig };
      setProject(updatedProject);
      
      const saved = JSON.parse(localStorage.getItem('science_projects') || '[]');
      const updatedProjects = saved.map((p: Project) => p.id === id ? updatedProject : p);
      localStorage.setItem('science_projects', JSON.stringify(updatedProjects));
      alert('تم حفظ الكود وتحديث المختبر!');
    } catch (e) {
      alert('خطأ في بناء كود JSON! يرجى التأكد من الصيغة.');
    }
  };

  const handleSpeak = async () => {
    if (!project?.guide || isSpeaking) return;
    setIsSpeaking(true);
    const audioData = await speakExplanation(project.guide);
    if (audioData) await playPCM(audioData);
    setIsSpeaking(false);
  };

  if (!project) return null;

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <button 
          onClick={() => navigate('/')}
          className="flex items-center gap-2 text-white/60 hover:text-white"
        >
          <ArrowRight size={20} />
          المكتبة
        </button>
        <div className="flex gap-2">
           <button 
            onClick={() => setShowCode(!showCode)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl border transition-all ${showCode ? 'bg-blue-600 border-blue-400 text-white' : 'glass-panel text-white/60'}`}
          >
            <Code size={18} />
            {showCode ? 'إخفاء الكود' : 'البرمجة اليدوية'}
          </button>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        <div className="flex-1 space-y-6">
          <div className="glass-panel p-6 rounded-3xl border-b-4 border-blue-600/20">
            <h2 className="text-3xl font-bold mb-2">{project.name}</h2>
            <p className="text-white/40 text-sm italic">نمط المحاكاة: {project.type}</p>
          </div>
          
          <div className="relative">
            {/* المحاكيات هنا ستعمل مع الإعدادات البرمجية */}
            <div className="opacity-90">
                {project.type === 'chemistry' && <ChemistryLab />}
                {project.type === 'physics' && <PhysicsLab />}
                {project.type === 'math' && <MathLab />}
            </div>
          </div>
        </div>

        <div className="w-full lg:w-96 space-y-6">
          {showCode ? (
            <div className="glass-panel rounded-3xl overflow-hidden flex flex-col h-[600px] border-l-4 border-amber-500">
                <div className="p-4 bg-amber-500/10 border-b border-white/10 flex justify-between items-center font-bold text-amber-500">
                   <div className="flex items-center gap-2">
                     <Code size={18} />
                     <span>محرر الكود</span>
                   </div>
                   <button onClick={handleSaveCode} className="p-2 hover:bg-amber-500/20 rounded-lg">
                     <Save size={18} />
                   </button>
                </div>
                <textarea 
                  value={editableCode}
                  onChange={e => setEditableCode(e.target.value)}
                  className="flex-1 p-4 bg-black/40 text-emerald-400 font-mono text-xs outline-none resize-none"
                  spellCheck={false}
                />
                <div className="p-4 text-[10px] text-white/30">
                  يمكنك تعديل القيم البرمجية أعلاه لتغيير سلوك المختبر مباشرة.
                </div>
            </div>
          ) : (
            <div className="glass-panel rounded-3xl overflow-hidden flex flex-col h-[600px] border-l-4 border-blue-500">
                <div className="p-6 bg-white/5 border-b border-white/10 flex justify-between items-center">
                  <div className="flex items-center gap-2 font-bold text-blue-400">
                    <BookOpen size={20} />
                    <span>دليل الذكاء الاصطناعي</span>
                  </div>
                  <button onClick={handleSpeak} disabled={isSpeaking} className={`p-2 rounded-lg ${isSpeaking ? 'text-blue-400 animate-pulse' : 'text-white/60'}`}>
                    <Volume2 size={20} />
                  </button>
                </div>
                <div className="p-6 overflow-y-auto text-sm text-white/80 whitespace-pre-wrap leading-relaxed">
                  {project.guide}
                </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default UserProjectLab;
