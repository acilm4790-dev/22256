
import React, { useState, useEffect } from 'react';
import * as Router from 'react-router-dom';
const { Link, useNavigate } = Router as any;
import { Beaker, Atom, Calculator, ArrowLeft, Plus, FolderOpen, Trash2, X, Sparkles, PlusCircle, Code } from 'lucide-react';
import { generateProjectData } from '../services/gemini';

interface Project {
  id: string;
  name: string;
  type: 'physics' | 'chemistry' | 'math';
  description: string;
  guide?: string;
  config: any;
  createdAt: number;
}

const LabCard = ({ title, description, icon: Icon, color, to }: any) => (
  <Link to={to} className="group flex-1">
    <div className={`h-full p-8 glass-panel rounded-3xl three-d-card flex flex-col items-center text-center transition-all duration-500 border-t-2 ${color}`}>
      <div className="mb-6 p-6 bg-white/5 rounded-2xl group-hover:scale-110 transition-transform duration-500">
        <Icon size={64} className="text-white opacity-80" />
      </div>
      <h3 className="text-2xl font-bold mb-4">{title}</h3>
      <p className="text-white/60 leading-relaxed mb-6">{description}</p>
      <div className="mt-auto flex items-center gap-2 text-sm font-semibold opacity-0 group-hover:opacity-100 transition-opacity translate-x-4 group-hover:translate-x-0">
        <span>استكشف المعمل</span>
        <ArrowLeft size={16} />
      </div>
    </div>
  </Link>
);

const HomeView: React.FC = () => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newProject, setNewProject] = useState({ name: '', type: 'physics', description: '' });
  const [isCreating, setIsCreating] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const saved = localStorage.getItem('science_projects');
    if (saved) setProjects(JSON.parse(saved));
  }, []);

  const saveProjects = (updated: Project[]) => {
    setProjects(updated);
    localStorage.setItem('science_projects', JSON.stringify(updated));
  };

  const handleCreateProject = async () => {
    if (!newProject.name) return;
    setIsCreating(true);
    
    const aiData = await generateProjectData(newProject.name, newProject.type);

    const project: Project = {
      id: Math.random().toString(36).substr(2, 9),
      name: newProject.name,
      type: newProject.type as any,
      description: newProject.description,
      guide: aiData?.guide || 'لم يتم توليد الدليل.',
      config: aiData?.config || {},
      createdAt: Date.now()
    };

    saveProjects([project, ...projects]);
    setIsCreating(false);
    setIsModalOpen(false);
    setNewProject({ name: '', type: 'physics', description: '' });
  };

  const deleteProject = (id: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const updated = projects.filter(p => p.id !== id);
    saveProjects(updated);
  };

  return (
    <div className="max-w-6xl mx-auto py-10">
      <div className="text-center mb-16 space-y-4">
        <h2 className="text-5xl font-extrabold tracking-tight">
          مستقبل <span className="text-blue-500">التعليم</span> المبرمج
        </h2>
        <p className="text-xl text-white/50 max-w-2xl mx-auto">
          أنشئ تجاربك الخاصة ودع Gemini يقوم بالبرمجة، ثم عدلها بنفسك يدوياً.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
        <LabCard 
          title="معمل الكيمياء" 
          description="تفاعلات العناصر وخصائص المحاليل."
          icon={Beaker}
          color="border-pink-500/50"
          to="/chemistry"
        />
        <LabCard 
          title="معمل الفيزياء" 
          description="الحركة، القوى، والجاذبية الأرضية."
          icon={Atom}
          color="border-emerald-500/50"
          to="/physics"
        />
        <LabCard 
          title="معمل الرياضيات" 
          description="الأشكال الهندسية والحسابات الفراغية."
          icon={Calculator}
          color="border-amber-500/50"
          to="/math"
        />
      </div>

      <div className="mt-20">
        <div className="flex justify-between items-center mb-8">
          <h3 className="text-3xl font-bold flex items-center gap-3">
            <Code className="text-blue-400" />
            المشاريع المبرمجة
          </h3>
          <button 
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl shadow-lg transition-all"
          >
            <PlusCircle size={20} />
            برمجة مشروع جديد
          </button>
        </div>

        {projects.length === 0 ? (
          <div className="p-16 glass-panel rounded-3xl text-center border-dashed border-2 border-white/10">
            <p className="text-white/40">لا توجد مشاريع مبرمجة حالياً.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map(project => (
              <Link 
                key={project.id} 
                to={`/project/${project.id}`}
                className="group relative glass-panel p-6 rounded-2xl border-r-4 border-blue-500/50 hover:bg-white/10 transition-all"
              >
                <button 
                  onClick={(e) => deleteProject(project.id, e)}
                  className="absolute top-4 left-4 p-2 text-white/20 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
                >
                  <Trash2 size={16} />
                </button>
                <h4 className="text-xl font-bold mb-2 group-hover:text-blue-400">{project.name}</h4>
                <div className="mt-4 pt-4 border-t border-white/5 flex justify-between items-center text-xs text-white/30">
                  <span className="flex items-center gap-1"><Code size={12}/> كود Gemini جاهز</span>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => !isCreating && setIsModalOpen(false)} />
          <div className="relative glass-panel w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden">
            <div className="p-6 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-bold">
              تحديد فكرة المشروع البرمجي
            </div>
            <div className="p-8 space-y-6">
              <input 
                type="text" 
                value={newProject.name}
                onChange={e => setNewProject({...newProject, name: e.target.value})}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:border-blue-500 outline-none"
                placeholder="اسم المشروع (مثلاً: مدار القمر)"
              />
              <div className="grid grid-cols-3 gap-2">
                {(['physics', 'chemistry', 'math'] as const).map(type => (
                  <button
                    key={type}
                    onClick={() => setNewProject({...newProject, type})}
                    className={`py-3 rounded-xl border transition-all text-xs font-bold ${newProject.type === type ? 'bg-blue-600 border-blue-400' : 'bg-white/5 border-white/10'}`}
                  >
                    {type === 'physics' ? 'فيزياء' : type === 'chemistry' ? 'كيمياء' : 'رياضيات'}
                  </button>
                ))}
              </div>
              <button 
                onClick={handleCreateProject}
                disabled={isCreating || !newProject.name}
                className="w-full py-4 bg-blue-600 text-white rounded-2xl font-bold shadow-xl flex items-center justify-center gap-3"
              >
                {isCreating ? 'جاري البرمجة بواسطة AI...' : 'ابدأ البرمجة'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default HomeView;
