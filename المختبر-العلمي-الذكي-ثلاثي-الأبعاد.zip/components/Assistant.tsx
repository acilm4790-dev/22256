
import React, { useState } from 'react';
import { Sparkles, MessageSquare, Volume2, Send, Loader2 } from 'lucide-react';
import { generateExplanation, speakExplanation, playPCM } from '../services/gemini';

const Assistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [response, setResponse] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const handleAsk = async () => {
    if (!query.trim()) return;
    
    setIsLoading(true);
    setResponse('');
    const text = await generateExplanation(query);
    setResponse(text || '');
    setIsLoading(false);
    setQuery('');
  };

  const handleSpeak = async () => {
    if (!response || isSpeaking) return;
    setIsSpeaking(true);
    const audioData = await speakExplanation(response);
    if (audioData) {
      await playPCM(audioData);
    }
    setIsSpeaking(false);
  };

  return (
    <div className="fixed bottom-24 right-6 z-50">
      {isOpen ? (
        <div className="w-80 md:w-96 glass-panel rounded-3xl overflow-hidden shadow-2xl animate-in slide-in-from-bottom-4 duration-300">
          <div className="p-4 bg-gradient-to-r from-blue-600 to-purple-600 flex justify-between items-center">
            <div className="flex items-center gap-2 text-white font-bold">
              <Sparkles size={18} />
              <span>مساعد المختبر الذكي</span>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-white/80 hover:text-white">✕</button>
          </div>
          
          <div className="p-6 h-[400px] overflow-y-auto space-y-4 scrollbar-hide">
            {response ? (
              <div className="space-y-4">
                <div className="p-4 bg-white/5 rounded-2xl border border-white/10 text-sm leading-relaxed">
                  {response}
                </div>
                <button 
                  onClick={handleSpeak}
                  disabled={isSpeaking}
                  className="flex items-center gap-2 text-xs font-bold text-blue-400 hover:text-blue-300 disabled:opacity-50"
                >
                  <Volume2 size={16} />
                  {isSpeaking ? 'جاري القراءة...' : 'استمع للشرح بصوت عالٍ'}
                </button>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-4 text-white/40">
                <MessageSquare size={48} className="opacity-20" />
                <p>اسألني أي شيء عن التجربة الحالية!</p>
              </div>
            )}
            
            {isLoading && (
              <div className="flex justify-center">
                <Loader2 className="animate-spin text-blue-500" />
              </div>
            )}
          </div>

          <div className="p-4 bg-white/5 border-t border-white/10 flex gap-2">
            <input 
              type="text" 
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAsk()}
              placeholder="اكتب سؤالك هنا..."
              className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-2 text-sm focus:outline-none focus:border-blue-500 transition-all"
            />
            <button 
              onClick={handleAsk}
              className="p-2 bg-blue-600 text-white rounded-xl hover:bg-blue-500 transition-all"
            >
              <Send size={18} />
            </button>
          </div>
        </div>
      ) : (
        <button 
          onClick={() => setIsOpen(true)}
          className="w-14 h-14 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-all animate-float border-2 border-white/20"
        >
          <Sparkles className="text-white" size={28} />
        </button>
      )}
    </div>
  );
};

export default Assistant;
